﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Amazon Native - Billing v2.0")]
	public class AMN_Purchase : FsmStateAction {
		
		public FsmEvent successEvent;
		public FsmEvent failedEvent;
		
		public FsmString SKU;
		
		public FsmString requestId;
		public FsmString userId;
		public FsmString marketplace;
		public FsmString receiptId;
		public FsmInt cancelDate;
		public FsmInt purchaseDate ;
		public FsmString sku;
		public FsmString productType;
		public FsmString status;
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			SA_AmazonBillingManager.Instance.OnPurchaseProductReceived += OnPurchaseProductReceived;
			SA_AmazonBillingManager.Instance.Purchase (SKU.Value);
		}
		
		void OnPurchaseProductReceived (AMN_PurchaseResponse result) {
			SA_AmazonBillingManager.Instance.OnPurchaseProductReceived -= OnPurchaseProductReceived;
			
			if(result.isSuccess) {
				requestId.Value    = result.RequestId;
				userId.Value	   = result.UserId;
				marketplace.Value  = result.Marketplace;
				receiptId.Value    = result.ReceiptId;
				cancelDate.Value   = (int)result.CancelDate;
				purchaseDate.Value = (int)result.PurchaseDatee;
				sku.Value          = result.Sku;
				productType.Value  = result.ProductType;
				status.Value       = result.Status;
				
				Fsm.Event(successEvent);
			}
			else {
				Fsm.Event(failedEvent);
			}			
			
			Finish();
		}
	}
}
