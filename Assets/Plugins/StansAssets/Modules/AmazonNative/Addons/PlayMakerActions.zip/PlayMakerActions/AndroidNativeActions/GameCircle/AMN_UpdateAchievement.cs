﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Amazon Native - GameCircle")]
	public class AMN_UpdateAchievement : FsmStateAction {
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public FsmString achieve_id;
		public FsmFloat score;

		public FsmString reason;
		public FsmString achievementId;
				
		public override void OnEnter() {
			SA_AmazonGameCircleManager.Instance.OnUpdateAchievementReceived += OnUpdateAchievementReceived;
			SA_AmazonGameCircleManager.Instance.UpdateAchievementProgress (achieve_id.Value, score.Value);
		}

		void OnUpdateAchievementReceived(AMN_UpdateAchievementResult result) {
			if (result.isSuccess) {
				achievementId.Value = result.AchievementID;

				Fsm.Event(successEvent);
			} else {
				reason.Value = result.Error;				
				achievementId.Value = result.AchievementID;

				Fsm.Event(failEvent);
			}
			
			Finish();
		}
	}
}