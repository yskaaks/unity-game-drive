﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Amazon Native - GameCircle")]
	public class AMN_GameCircleInit : FsmStateAction {

		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			SA_AmazonGameCircleManager.Instance.OnInitializeResult += OnInitializeResult;
			SA_AmazonGameCircleManager.Instance.Connect ();			
		}

		void OnInitializeResult(AMN_InitializeResult result) {
			if (result.isSuccess) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}

			Finish();
		}

	}
}

