﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Amazon Native - GameCircle")]
	public class AMN_LoadGCLeaderboards : FsmStateAction {
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		public FsmString reason;
		
		public FsmString name;
		public FsmString id;
		public FsmString displayText;
		public FsmString scoreFormat;
		public FsmString imageUrl;
		
		public override void OnEnter() {			
			SA_AmazonGameCircleManager.Instance.OnRequestLeaderboardsReceived += OnRequestLeaderboardsReceived;
			SA_AmazonGameCircleManager.Instance.RequestLeaderboards ();
		}
		
		void OnRequestLeaderboardsReceived(AMN_RequestLeaderboardsResult result) {
			if (result.isSuccess) {

				name.Value = result.LeaderboardsList[0].Title;
				id.Value = result.LeaderboardsList[0].Identifier;
				displayText.Value = result.LeaderboardsList[0].Description;
				scoreFormat.Value = result.LeaderboardsList[0].ScoreFormat;
				imageUrl.Value = result.LeaderboardsList[0].ImageUrl;

				Fsm.Event(successEvent);
			} else {
				reason.Value = result.Error;

				Fsm.Event(failEvent);
			}
			
			Finish();
		}
	}
}

